pipe = class:new()

function pipe:init(x, y, height)
	self.x = x
	self.y = y
	self.height = height
	self.width = 26
	self.givepoint = {}
	for i = 1, players do
		table.insert(self.givepoint, true)
	end
	
	if difficulty == "hard" then
		if self.y == 0 then
			self.piston = math.random(1, 5) == 1
			self.oldheight = self.height
			self.dir = 1
			self.pistonspeed = math.random(5, 40)
		else
			if objects.pipe[#objects.pipe].piston then
				self.piston = true
				self.oldy = self.y
				self.dir = 1
				self.pistonspeed = objects.pipe[#objects.pipe].pistonspeed
			end
		end
		self.topimg = piperedtopimg
		self.bodyimg = piperedimg
	else
		self.topimg = pipetopimg
		self.bodyimg = pipeimg
	end
end

function pipe:update(dt)
	if doscroll then
		self.x = self.x - 60*dt
		if self.x+self.width <= 0 then
			return true
		end
		for j, w in pairs(objects.bird) do
			if self.y == 0 and w.x+(w.width/2) >= self.x+(self.width/2) and self.givepoint[w.t] and not w.dead then
				points[w.t] = points[w.t] + 1
				playsound(pointsound)
				self.givepoint[w.t] = false
			end
		end
	end
	if self.piston then
		if self.y == 0 then
			if self.dir == 1 then
				self.height = self.height + self.pistonspeed*dt
				if self.height >= self.oldheight+10 then
					self.dir = 2
				end
			else
				self.height = self.height - self.pistonspeed*dt
				if self.height <= self.oldheight then
					self.dir = 1
				end
			end
		else
			if self.dir == 1 then
				self.y = self.y + self.pistonspeed*dt
				self.height = self.height - self.pistonspeed*dt
				if self.y >= self.oldy+10 then
					self.dir = 2
				end
			else
				self.y = self.y - self.pistonspeed*dt
				self.height = self.height + self.pistonspeed*dt
				if self.y <= self.oldy then
					self.dir = 1
				end
			end
		end
	end
end

function pipe:draw()
	love.graphics.setColor(255, 255, 255)
	if self.y == 0 then
		love.graphics.draw(self.topimg, self.x*scale, (self.y+self.height)*scale, 0, scale, -scale)
		local x = math.max(0, self.x)
		if self.piston then
			love.graphics.setScissor(x*scale, self.y*scale, (x+self.width)*scale,(self.y+self.height-11.5)*scale)
		else
			love.graphics.setScissor(x*scale, self.y*scale, (x+self.width)*scale,(self.y+self.height-12)*scale)
		end
		love.graphics.draw(self.bodyimg, (self.x+1)*scale, self.y*scale, 0, scale, scale)
		love.graphics.setScissor()
	else
		love.graphics.draw(self.topimg, self.x*scale, self.y*scale, 0, scale, scale)
		local x = math.max(0, self.x)
		love.graphics.setScissor(x*scale, self.y*scale, (x+self.width)*scale, (self.y+self.height)*scale)
		love.graphics.draw(self.bodyimg, (self.x+1)*scale, (self.y+12)*scale, 0, scale, scale)
		love.graphics.setScissor()
	end
end