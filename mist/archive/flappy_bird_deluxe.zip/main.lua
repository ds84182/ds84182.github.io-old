--[[
	THIS AWESOME GAME WAS MADE BY ALESAN99
	DON'T CLAIM THIS CODE AS YOUR OWN
	
	Most graphics belong to .GEARS STUDIOS
]]

function love.load()
	RUNGAME=true

	math.randomseed(os.time())
	math.random();math.random();math.random()
	require "class"
	
	require "intro"
	require "menu"
	require "game"
	
	require "bird"
	require "pipe"
	require "button"
	
	love.filesystem.setIdentity("flappy_bird_deluxe")
	
	love.graphics.setDefaultFilter("nearest")
	love.graphics.present()
	
	--SETTINGS
	highscore = {0, 0, 0}
	champ = {0, 0, 0}
	character = "bird"
	flappycoins = 0
	volume = 1
	difficulty = "normal"
	difficultynum = 2
	scale = 2
	players = 1
	
	if love.filesystem.exists("save.alesan") then
		local s = love.filesystem.read("save.alesan")
		s2 = s:split("~")
		highscore = {}
		local s3 = s2[2]:split(",")
		for i = 1, 3 do
			highscore[i] = tonumber(s3[i])
		end
		champ = {}
		local s3 = s2[3]:split(",")
		for i = 1, 3 do
			champ[i] = tonumber(s3[i])
		end
		flappycoins = tonumber(s2[4])
		volume = tonumber(s2[5])
		difficulty = s2[6]
		if difficulty == "normal" then difficultynum = 2 elseif difficulty == "hard" then difficultynum = 3 else difficultynum = 1 end
		scale = tonumber(s2[7])
	end
	
	love.audio.setVolume(volume)
	
	--SET WINDOW STUFF
	background = love.graphics.newImage("images/background.png")
	background2 = love.graphics.newImage("images/background2.png")
	background3 = love.graphics.newImage("images/background3.png")
	setscale(scale)
	love.window.setIcon(love.image.newImageData("images/icon.png"))
	love.window.setTitle("Flappy Bird DELUXE")
	
	--IMAGES
	alesanimg = love.graphics.newImage("alesan.png")
	
	groundimg = love.graphics.newImage("images/ground.png")
	logoimg = love.graphics.newImage("images/logo.png")
	
	scoreboardimg = love.graphics.newImage("images/scoreboard.png")
	optionsboardimg = love.graphics.newImage("images/settingsboard.png")
	newhighscoreimg = love.graphics.newImage("images/newhighscore.png")
	medalsimg = love.graphics.newImage("images/medals.png")
	medalsquad = {}
	for x = 1, 4 do
		medalsquad[x] = love.graphics.newQuad((x-1)*22, 0, 22, 22, 88, 22)
	end
	
	flappycoinimg = love.graphics.newImage("images/flappycoin.png")
	
	gameoverimg = love.graphics.newImage("images/gameover.png")
	getreadyimg = love.graphics.newImage("images/getready.png")
	
	numbersimg = love.graphics.newImage("images/numbers.png")
	numbersquad = {}
	for x = 0, 9 do
		numbersquad[x] = love.graphics.newQuad(x*7, 0, 7, 10, 70, 10)
	end
	
	fontimg = love.graphics.newImage("images/font.png")
	fontstring = "abcdefghijklmnopqrstuvwxyz.!? <>0123456789="
	fontcharwidth = {4, 4, 3, 4, 3, 3, 4, 4, 3, 4, 4, 3, 5, 4, 4, 4, 5, 4, 4, 3, 4, 5, 5, 5, 5, 5, 2, 2, 4, 4, 4, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 5}
	fontquad = {}
	for x = 1, fontimg:getWidth()/5 do
		fontquad[string.sub(fontstring, x, x)] = {}
		fontquad[string.sub(fontstring, x, x)]["img"] = love.graphics.newQuad((x-1)*5, 0, 5, 5, fontimg:getWidth(), 5)
		fontquad[string.sub(fontstring, x, x)]["width"] = fontcharwidth[x] or 5
	end
	
	birdimg = love.graphics.newImage("images/bird.png")
	crownimg = love.graphics.newImage("images/crown.png")
	birdquad = {}
	for x = 1, 4 do
		birdquad[x] = {}
		for y = 1, 4 do
			birdquad[x][y] = love.graphics.newQuad((x-1)*17, (y-1)*12, 17, 12, 68, 48)
		end
	end
	
	pipeimg = love.graphics.newImage("images/pipe.png")
	pipetopimg = love.graphics.newImage("images/pipetop.png")
	piperedimg = love.graphics.newImage("images/pipered.png")
	piperedtopimg = love.graphics.newImage("images/piperedtop.png")
	
	--SOUNDS
	flapsound = love.audio.newSource("sounds/flap.ogg")
	pointsound = love.audio.newSource("sounds/point.ogg")
	hitsound = love.audio.newSource("sounds/hit.ogg")
	diesound = love.audio.newSource("sounds/die.ogg")
	wooshsound = love.audio.newSource("sounds/woosh.ogg")
	
	--MOUSE
		mouse = {x=love.mouse.getX(),y=love.mouse.getY(),getcursor="arrow"}
	mouse.cursor = {}
	mouse.cursor.arrow = love.mouse.getSystemCursor("arrow") or false
	mouse.cursor.hand = love.mouse.getSystemCursor("hand") or false
	mouse.cursor.wait = love.mouse.getSystemCursor("wait") or false
	mouse.cursor.ibeam = love.mouse.getSystemCursor("ibeam") or false
	mouse.cursor.set =  function(cursor) 
							if mouse.cursor[cursor] then
								love.mouse.setCursor(mouse.cursor[cursor])
								mouse.getcursor = cursor
							end
						end
	
	--START GAME DURRR
	
	setgamestate("intro")
end

function love.update(dt)
	if not RUNGAME then
		return
	end
	if _G[gamestate].update then
		_G[gamestate].update(dt)
	end
end

function love.draw()
	if _G[gamestate].draw then
		_G[gamestate].draw()
	end
end

function love.keypressed(key)
	if not RUNGAME then
		return
	end
	if _G[gamestate].keypressed then
		_G[gamestate].keypressed(key)
	end
end

function love.mousepressed(x, y, button)
	if not RUNGAME then
		return
	end
	if _G[gamestate].mousepressed then
		_G[gamestate].mousepressed(x, y, button)
	end
end

function love.mousereleased(x, y, button)
	if not RUNGAME then
		return
	end
	if _G[gamestate].mousereleased then
		_G[gamestate].mousereleased(x, y, button)
	end
end

function setgamestate(state)
	_G[state].load()
	gamestate = state
end

local function error_printer(msg, layer)
    print((debug.traceback("Error: " .. tostring(msg), 1+(layer or 1)):gsub("\n[^\n]+$", "")))
end

function love.errhand(msg)
	if love.graphics.newScreenshot then
		local screendata = love.graphics.newScreenshot()
		local screen = love.graphics.newImage(screendata)
	end
	
    msg = tostring(msg)

    error_printer(msg, 2)

    if not love.window or not love.graphics or not love.event then
        return
    end

    if not love.graphics.isCreated() or not love.window.isCreated() then
        if not pcall(love.window.setMode, 800, 600) then
            return
        end
    end

    -- Reset state.
    if love.mouse then
        love.mouse.setVisible(true)
        love.mouse.setGrabbed(false)
    end
    if love.joystick then
        for i,v in ipairs(love.joystick.getJoysticks()) do
            v:setVibration() -- Stop all joystick vibrations.
        end
    end
    if love.audio then
		love.audio.stop()
	end
	love.graphics.reset()
    love.graphics.setBackgroundColor(89, 157, 220)
    local font = love.graphics.setNewFont(14)
	if love.window.getWidth and love.window.getHeight then
		local winwidth = love.window.getWidth()
		local winheight = love.window.getHeight()
	end

    love.graphics.setColor(255, 255, 255, 255)

    local trace = debug.traceback()

    love.graphics.clear()
    love.graphics.origin()

    local err = {}

    table.insert(err, "Error\n")
    table.insert(err, msg.."\n\n")
	
	table.insert(err, "LOVE " .. (love._version or "UNKNOWN") .. " running on " .. (love.system.getOS() or "UNKNOWN") .. "\n\n")

    for l in string.gmatch(trace, "(.-)\n") do
        if not string.match(l, "boot.lua") then
            l = string.gsub(l, "stack traceback:", "Traceback\n")
            table.insert(err, l)
        end
    end

    local p = table.concat(err, "\n")

    p = string.gsub(p, "\t", "")
    p = string.gsub(p, "%[string \"(.-)\"%]", "%1")

    local function draw()
        love.graphics.clear()
		if screen then
			love.graphics.draw(screen,0,0)
		end
		love.graphics.setColor(0, 0, 0, 150)
		love.graphics.rectangle("fill", 0, 0, winwidth or 1000, winheight or 1000)
		love.graphics.setColor(255, 255, 255, 255)
        love.graphics.printf(p, 10, 20, love.graphics.getWidth() - 20)
        love.graphics.present()
    end

    while true do
        love.event.pump()

        for e, a, b, c in love.event.poll() do
            if e == "quit" then
                return
            end
            if e == "keypressed" and a == "escape" then
                return
            end
        end

        draw()

        if love.timer then
            love.timer.sleep(0.1)
        end
    end
end

function updateobjects(dt) --Mari0
	for i, v in pairs(objects) do
		local delete = {}
		
		for j, w in pairs(v) do
			if w.update and w:update(dt) then
				table.insert(delete, j)
			elseif w.delete then
				table.insert(delete, j)
			end
		end
		
		if #delete > 0 then
			table.sort(delete, function(a,b) return a>b end)
			
			for j, w in pairs(delete) do
				table.remove(v, w)
			end
		end
	end
end

function string:split(delimiter) --Not by me
	local result = {}
	local from  = 1
	local delim_from, delim_to = string.find( self, delimiter, from  )
	while delim_from do
		table.insert( result, string.sub( self, from , delim_from-1 ) )
		from = delim_to + 1
		delim_from, delim_to = string.find( self, delimiter, from  )
	end
	table.insert( result, string.sub( self, from  ) )
	return result
end

function setscale(s)
	love.graphics.setNewFont(6*s)
	love.window.setMode(background:getWidth()*s, background:getHeight()*s)
end

function printtext(s, x, y)
	local s = s:lower()
	local length = s:len()
	local location = 0
	for i = 0, length-1 do
		local char = s:sub(location+1, location+1)
		if fontquad[char] then
			love.graphics.draw(fontimg, fontquad[char]["img"], x, y, 0, scale, scale)
			location = location + 1
			x = ((fontquad[char]["width"] or 4)+1)*scale + x
		end
	end
end

function string:getTextWidth() --made this since each char has a different width
	local length = self:len()
	local width = 0
	local char = ""
	local x = 0
	local spacing = 1
	for i = 0, length-1 do
		char = self:sub(i+1, i+1):lower()
		if i == length then
			spacing = 0
		end
		if fontquad[char] then
			x = x + ((fontquad[char]["width"] or 4)+spacing)
		end
	end
	return x-1
end

function saveoptions()
	local s = "Honestly I don't care if you cheat, but please don't post fake scores on the forums."
	s = s .. "~" .. highscore[1] .. "," .. highscore[2] .. "," .. highscore[3] .. "~" .. champ[1] .. "," .. champ[2] .. "," .. champ[3]
	s = s .. "~" .. flappycoins .. "~" .. volume .. "~" ..difficulty .. "~" .. scale
	love.filesystem.write("save.alesan", s)
end

function getSize(img)
	return img:getWidth(), img:getHeight()
end

function playsound(sound)
	sound:stop()
	sound:play()
end

function love.focus(f) if not f then RUNGAME=false else RUNGAME=true end end