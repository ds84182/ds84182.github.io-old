game = {}

local groundbirds = 0

function game.load()
	fadetogame = 255
	fadetomenu = 0

	objects = {}
	objects.bird = {}
	objects.pipe = {}
	objects.button = {}
	for i = 1, players do
		objects.bird[i] = bird:new((i-1)*15+30, i)
	end
	objects.button.pause = button:new("=", 10, 30, 14, 14, "main", function() 
																	paused = not paused
																	if paused then
																		objects.button.pause.text = ">" 
																	else 
																		objects.button.pause.text = "="
																	end
																   end)
	scroll = 0
	dosroll = true
	groundscroll = 0
	floattimer = 0
	pipetimer = 0
	pipespace = math.random(26, 140)
	points = {}
	for i = 1, players do
		table.insert(points, 0)
	end
	paused = false
	deadaction = false
	medal = false
	retry = false
	highestscore = 0
	oldhighscore = highscore[difficultynum]
	print(oldhighscore)
	getreadya = 0
	gameovery = 40 --max = 50
	gameovera = 0
	scoreboardy = 256
	
	if difficulty == "easy" then
		pipespawndelay = 2.5
	elseif difficulty == "hard" then
		pipespawndelay = 1.2
	else
		pipespawndelay = 1.5
	end
	
	woosh = false
end

function game.update(dt)
	if fadetogame ~= 0 then
		fadetogame = math.max(0, fadetogame - 500*dt)
	elseif fadetomenu ~= 0 then
		fadetomenu = math.min(255, fadetomenu + 500*dt)
		if fadetomenu == 255 then
			if retry then
				setgamestate("game")
			else
				setgamestate("menu")
			end
			return
		end
	end
	
	local buttons = 0
	local buttonsoff = 0
	for j, w in pairs(objects.button) do
		if not w.mouseon then
			buttonsoff = buttonsoff + 1
		end
		buttons = buttons + 1
	end
	if buttonsoff == buttons then
		if mouse.getcursor ~= "arrow" then
			mouse.cursor.set("arrow")
		end
	else
		if mouse.getcursor ~= "hand" then
			mouse.cursor.set("hand")
		end
	end
	
	if paused then
		for j, w in pairs(objects.button) do
			w:update(dt)
		end
		return
	end
	local deadbirds = 0
	local flappingbirds = 0 --FLAP!!!
	groundbirds = 0 --birds on the ground
	for j, w in pairs(objects.bird) do
		if w.dead then
			deadbirds = deadbirds + 1
		end
		if w.flap then
			flappingbirds = flappingbirds + 1
		end
		if w.y == 186 then
			groundbirds = groundbirds + 1
		end
	end
	if deadbirds == players then
		doscroll = false
		if objects.button.pause then
			objects.button.pause = nil
		end
		if not deadaction then
			local topchamp = 0
			local oldchamp = champ[difficultynum]
			for i = 1, players do
				if points[i] > highscore[difficultynum] then
					topchamp = i
				end
			end
			if topchamp ~= 0 then
				highscore[difficultynum] = points[topchamp]
				champ[difficultynum] = topchamp
			end
			highestscore = 0
			currentchamp = 0
			for i = 1, players do
				if points[i] > highestscore then
					highestscore = points[i]
					currentchamp = i
				end
			end
			if highestscore >= 40 then
				medal = 4
			elseif highestscore >= 30 then
				medal = 3
			elseif highestscore >= 20 then
				medal = 2
			elseif highestscore >= 10 then
				medal = 1
			end
			local oldflappycoins = flappycoins
			if difficulty == "easy" then
				flappycoins = flappycoins + math.floor(highestscore/2.5)
			elseif difficulty == "hard" then
				flappycoins = flappycoins + math.floor(highestscore*1.5)
			else
				flappycoins = flappycoins + highestscore
			end
			if highscore[difficultynum] > oldhighscore or champ[difficultynum] ~= oldchamp or flappycoins ~= oldflappycoins then
				saveoptions()
			end
			deadaction = true
		end
	else
		doscroll = true
	end
	if groundbirds == players then
		if gameovera ~= 255 then
			gameovery = math.min(gameovery + (((50-gameovery)*7)*dt), 50)
			gameovera = math.min(gameovera + 500*dt, 255)
		elseif scoreboardy ~= 85 then
			scoreboardy = math.max(scoreboardy + -(((scoreboardy-83)*3.5)*dt), 85)
			if not woosh then
				playsound(wooshsound)
				woosh = true
			end
		elseif not objects.button.retry then
			objects.button.retry = button:new("RETRY", 20, 180, 40, 14, "main", function() fadetomenu = .00001; retry = true; objects.button.menu.static = true; objects.button.retry.static = true end)
			objects.button.menu = button:new("MENU", 84, 180, 40, 14, "main", function() fadetomenu = .00001; objects.button.menu.static = true; objects.button.retry.static = true end)
		end
	end
	if doscroll then
		scroll = scroll + 60*dt
		groundscroll = groundscroll + 60*dt
		while groundscroll >= 10 do
			groundscroll = groundscroll - 14
		end
	end
	if flappingbirds == players and doscroll then
		pipetimer = pipetimer + dt
		while pipetimer >= pipespawndelay do
			pipespace = math.random(26, 135)
			table.insert(objects.pipe, pipe:new(144, 0, pipespace))
			table.insert(objects.pipe, pipe:new(144, 200-(152-pipespace), (152-pipespace)))
			pipetimer = pipetimer - pipespawndelay
		end
	end
	if flappingbirds ~= players then
		getreadya = math.min(255, getreadya + 700*dt)
	elseif getreadya > 0 then
		getreadya = math.max(0, getreadya - 700*dt)
	end

	floattimer = floattimer + dt
		
	while floattimer > 1 do
		floattimer = floattimer - 1
	end
	
	local newy = (-math.cos(floattimer/1*math.pi*2)+1)/2*4 --Mari0
	floatoffsety = newy

	updateobjects(dt)
end

function game.draw()
	love.graphics.setColor(255, 255, 255)
	if difficulty == "hard" then
		love.graphics.draw(background2, 0, 0, 0, scale, scale)
	elseif difficulty == "easy" then
		love.graphics.draw(background3, 0, 0, 0, scale, scale)
	else
		love.graphics.draw(background, 0, 0, 0, scale, scale)
	end
	for j, w in pairs(objects.pipe) do
		w:draw()
	end
	for j, w in pairs(objects.bird) do
		w:draw()
	end
	love.graphics.draw(groundimg, (-groundscroll-4)*scale, 200*scale, 0, scale, scale)
	love.graphics.setColor(222, 216, 144)
	love.graphics.rectangle("fill", 0, 211*scale, 144*scale, 45*scale)
	if groundbirds ~= players then
		for i = 1, players do
			if i == 1 then
				if players == 1 then
					love.graphics.setColor(255, 255, 255)
				else
					love.graphics.setColor(242, 216, 0)
				end
			elseif i == 2 then
				love.graphics.setColor(255, 50, 30)
			elseif i == 3 then
				love.graphics.setColor(100, 100, 255)
			elseif i == 4 then
				love.graphics.setColor(0, 200, 0)
			end
			if players == 1 then
				numberprint(points[i], (((144/2)-string.len(tostring(points[i]))*4))*scale, 30*scale)
			else
				numberprint(points[i], (((144/2)-string.len(tostring(points[i]))*4)-math.abs((i-players)*20)+((players-1)*10))*scale, 30*scale)
			end
		end
	end
	if getreadya > 0 then
		love.graphics.setColor(255, 255, 255, getreadya)
		love.graphics.draw(getreadyimg, 28.5*scale, 60*scale, 0, scale, scale)
	end
	if groundbirds == players then
		love.graphics.setColor(255, 255, 255, gameovera)
		love.graphics.draw(gameoverimg, 25*scale, gameovery*scale, 0, scale, scale)
		love.graphics.setColor(255, 255, 255)
		love.graphics.draw(scoreboardimg, 15.5*scale, scoreboardy*scale, 0, scale, scale)
		if medal then
			love.graphics.draw(medalsimg, medalsquad[medal], 28.5*scale, (scoreboardy+21)*scale, 0, scale, scale)
		end
		if players > 1 then
			if currentchamp == 1 then
				love.graphics.setColor(242, 216, 0)
			elseif currentchamp == 2 then
				love.graphics.setColor(255, 50, 30)
			elseif currentchamp == 3 then
				love.graphics.setColor(100, 100, 255)
			elseif currentchamp == 4 then
				love.graphics.setColor(0, 200, 0)
			end
		end
		numberprint(highestscore, (118.5-string.len(tostring(highestscore))*8)*scale, (scoreboardy+17)*scale)
		love.graphics.setColor(255, 255, 255)
		if players > 1 then
			if champ[difficultynum] == 1 then
				love.graphics.setColor(242, 216, 0)
			elseif champ[difficultynum] == 2 then
				love.graphics.setColor(255, 50, 30)
			elseif champ[difficultynum] == 3 then
				love.graphics.setColor(100, 100, 255)
			elseif champ[difficultynum] == 4 then
				love.graphics.setColor(0, 200, 0)
			end
		end
		numberprint(highscore[difficultynum], (118.5-string.len(tostring(highscore[difficultynum]))*8)*scale, (scoreboardy+38)*scale)
		love.graphics.setColor(255, 255, 255)
		if highscore[difficultynum] > oldhighscore then
			love.graphics.draw(newhighscoreimg, 83.5*scale, (scoreboardy+29)*scale, 0, scale, scale)
		end
	end
	for j, w in pairs(objects.button) do
		w:draw()
	end
	love.graphics.setColor(255, 255, 255)
	love.graphics.draw(flappycoinimg, 5*scale, 230*scale, 0, scale, scale)
	printtext("x", 33*scale, 240*scale)
	numberprint(flappycoins, 42*scale, 238*scale)
	if fadetogame ~= 0 then
		love.graphics.setColor(0, 0, 0, fadetogame)
		love.graphics.rectangle("fill", 0, 0, 144*scale, 256*scale)
	elseif fadetomenu ~= 0 then
		love.graphics.setColor(0, 0, 0, fadetomenu)
		love.graphics.rectangle("fill", 0, 0, 144*scale, 256*scale)
	end
end

function numberprint(s, x, y)
	local offsety = 0
	local location = 1
	for i = 1, string.len(s) do
		local todochar = string.sub(s, i, i)
		love.graphics.draw(numbersimg, numbersquad[tonumber(todochar)], math.floor(((location-1)*8))*scale+(x), y, 0, scale, scale)
		location = location + 1
	end
end

function game.keypressed(key)
	if not paused then
		for j, w in pairs(objects.bird) do
			w:keypressed(key)
		end
	end
end

function game.mousepressed(x, y, button)
	if not paused then
		for j, w in pairs(objects.bird) do
			w:mousepressed(x, y, button)
		end
	end
	for j, w in pairs(objects.button) do
		w:mousepressed(x, y, button)
	end
end

function game.mousereleased(x, y, button)
	for j, w in pairs(objects.button) do
		w:mousereleased(x, y, button)
	end
end