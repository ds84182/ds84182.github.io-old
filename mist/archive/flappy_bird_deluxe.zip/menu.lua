menu = {}

function menu.load()
	fadetomenu = 255
	fadetogame = 0

	objects = {}
	objects.button = {}
	objects.button.start = button:new("START", 20, 180, 40, 14, "main", function() fadetogame = .00001; objects.button.start.static = true; objects.button.options.static = true end)
	objects.button.options = button:new("OPTIONS", 84, 180, 40, 14, "main", menu.openoptionsmenu)

	floatoffsety = 0
	floattimer = 0
	birdanimtimer = 0
	birdframe = 1
	scroll = 0
	groundscroll = 0
	optionsopen = false
	optionsy = 256
end

function menu.update(dt)
	if fadetomenu ~= 0 then
		fadetomenu = math.max(0, fadetomenu - 500*dt)
	elseif fadetogame ~= 0 then
		fadetogame = math.min(255, fadetogame + 500*dt)
		if fadetogame == 255 then
			setgamestate("game")
			return
		end
	end
	
	local buttons = 0
	local buttonsoff = 0
	for j, w in pairs(objects.button) do
		if not w.mouseon then
			buttonsoff = buttonsoff + 1
		end
		buttons = buttons + 1
	end
	if buttonsoff == buttons then
		if mouse.getcursor ~= "arrow" then
			mouse.cursor.set("arrow")
		end
	else
		if mouse.getcursor ~= "hand" then
			mouse.cursor.set("hand")
		end
	end
	
	if optionsopen then
		if optionsy ~= 45 then
			optionsy = math.max(optionsy - (((optionsy-44)*3)*dt), 45)
		end
	else
		if optionsy ~= 256 then
			optionsy = math.min(optionsy + (((270-optionsy)*3)*dt), 256)
		end
		if optionsy > 200 then
			if objects.button.start.static then
				objects.button.start.static = false
				objects.button.options.static = false
			end
		end
	end
	if objects.button.back then
		objects.button.back.y = optionsy+135
		objects.button.reset.y = optionsy+135
		objects.button.volume.y = optionsy+43
		objects.button.scale1.y = optionsy+65
		objects.button.scale1_5.y = optionsy+65
		objects.button.scale2.y = optionsy+65
		objects.button.playersl.y = optionsy+116
		objects.button.playersr.y = optionsy+116
		objects.button.difl.y = optionsy+91
		objects.button.difr.y = optionsy+91
	end

	scroll = scroll + 50*dt
	groundscroll = groundscroll + 50*dt
	while groundscroll > 10 do
		groundscroll = groundscroll - 14
	end

	floattimer = floattimer + dt
		
	while floattimer > 1 do
		floattimer = floattimer - 1
	end
	
	local newy = (-math.cos(floattimer/1*math.pi*2)+1)/2*4 --Mari0
	floatoffsety = newy
	
	birdanimtimer = birdanimtimer + dt
	while birdanimtimer > 0.1 do
		birdframe = birdframe + 1
		if birdframe > 4 then
			birdframe = 1
		end
		birdanimtimer = birdanimtimer - 0.1
	end
	updateobjects(dt)
end

function menu.draw()
	love.graphics.setColor(255, 255, 255)
	if difficulty == "hard" then
		love.graphics.draw(background2, 0, 0, 0, scale, scale)
	elseif difficulty == "easy" then
		love.graphics.draw(background3, 0, 0, 0, scale, scale)
	else
		love.graphics.draw(background, 0, 0, 0, scale, scale)
	end
	love.graphics.draw(groundimg, (-groundscroll-4)*scale, 200*scale, 0, scale, scale)
	love.graphics.draw(logoimg, 15*scale, (60+floatoffsety)*scale, 0, scale, scale)
	love.graphics.draw(birdimg, birdquad[birdframe][1], 120*scale, (75+floatoffsety)*scale, 0, scale, scale)
	love.graphics.setColor(222, 216, 144)
	love.graphics.rectangle("fill", 0, 211*scale, 144*scale, 45*scale)
	objects.button.start:draw()
	objects.button.options:draw()
	if optionsy ~= 256 then
		love.graphics.setColor(255, 255, 255)
		love.graphics.draw(optionsboardimg, 4*scale, optionsy*scale, 0, scale, scale)
		numberprint(highscore[difficultynum], ((144/2)-string.len(tostring(highscore[difficultynum]))*4)*scale, (optionsy+16)*scale)
		numberprint(players, ((144/2)-string.len(tostring(players))*4)*scale, (optionsy+118)*scale)
		printtext(difficulty, (144/2-(difficulty:getTextWidth()/2))*scale, (optionsy+96)*scale)
		objects.button.back:draw()
		objects.button.reset:draw()
		objects.button.volume:draw()
		objects.button.scale1:draw()
		objects.button.scale1_5:draw()
		objects.button.scale2:draw()
		objects.button.playersl:draw()
		objects.button.playersr:draw()
		objects.button.difl:draw()
		objects.button.difr:draw()
	end
	love.graphics.setColor(255, 255, 255)
	love.graphics.draw(flappycoinimg, 5*scale, 230*scale, 0, scale, scale)
	printtext("x", 33*scale, 240*scale)
	numberprint(flappycoins, 42*scale, 238*scale)
	
	if fadetogame ~= 0 then
		love.graphics.setColor(0, 0, 0, fadetogame)
		love.graphics.rectangle("fill", 0, 0, 144*scale, 256*scale)
	elseif fadetomenu ~= 0 then
		love.graphics.setColor(0, 0, 0, fadetomenu)
		love.graphics.rectangle("fill", 0, 0, 144*scale, 256*scale)
	end
end

function menu.keypressed(key)
	if key == "escape" then
		love.event.quit()
	end
end

function menu.mousepressed(x, y, button)
	for j, w in pairs(objects.button) do
		if fadetogame == 0 then
			w:mousepressed(x, y, button)
		end
	end
end

function menu.mousereleased(x, y, button)
	for j, w in pairs(objects.button) do
		if fadetogame == 0 then
			w:mousereleased(x, y, button)
		end
	end
end

function menu.openoptionsmenu()
	objects.button.start.static = true
	objects.button.options.static = true
	objects.button.back = button:new("BACK", 20, optionsy+135, 40, 14, "main", menu.closeoptionsmenu)
	objects.button.reset = button:new("RESET", 84, optionsy+135, 40, 14, "main", function() objects.button.volume.x = 68; scale = 2; setscale(scale); difficulty = "normal" end)
	objects.button.volume = button:new("", (((volume*24)-4)+48), optionsy+71, 8, 10, "slider", menu.openoptionsmenu)
	objects.button.scale1 = button:new("x1", 30, optionsy+67, 22, 14, "main", function() scale = 1; setscale(scale) end)
	objects.button.scale1_5 = button:new("x1.5", 60, optionsy+67, 22, 14, "main", function() scale = 1.5; setscale(scale) end)
	objects.button.scale2 = button:new("x2", 90, optionsy+67, 22, 14, "main", function() scale = 2; setscale(scale) end)
	objects.button.playersl = button:new("<", 47, optionsy+117, 14, 14, "main", function() players = math.max(1, players-1) end)
	objects.button.playersr = button:new(">", 83, optionsy+117, 14, 14, "main", function() players = math.min(4, players+1) end)
	objects.button.difl = button:new("<", 40, optionsy+92, 14, 14, "main", setdifficulty, {"<"})
	objects.button.difr = button:new(">", 90, optionsy+92, 14, 14, "main", setdifficulty)
	optionsopen = true
end

function menu.closeoptionsmenu()
	volume = ((objects.button.volume.x+4)-48)/24
	love.audio.setVolume(volume)
	saveoptions()
	optionsopen = false
end

function setdifficulty(d)
	if d == "<" then
		if difficulty == "normal" then
			difficulty = "easy"
		elseif difficulty == "easy" then
			difficulty = "hard"
		else
			difficulty = "normal"
		end
	else
		if difficulty == "hard" then
			difficulty = "easy"
		elseif difficulty == "normal" then
			difficulty = "hard"
		else
			difficulty = "normal"
		end
	end
	if difficulty == "normal" then difficultynum = 2 elseif difficulty == "hard" then difficultynum = 3 else difficultynum = 1 end
end