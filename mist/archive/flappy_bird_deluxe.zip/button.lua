button = class:new()

function button:init(text, x, y, width, height, t, func, arg)
	self.text = text or "ERROR"
	self.x = x or 0
	self.y = y or 0
	self.t = t or "main"
	self.width = width
	self.height = height
	self.func = func or function() end
	self.arg = arg or false
	
	self.mouseon = false
	self.yoffset = 0
end

function button:update(dt)
	self.mouseon = self:checkmouseon()
	if self.t == "slider" then
		if self.yoffset == 1 then
			self.x = math.max(math.min(92, (love.mouse.getX()/scale)-(self.width/2)), 44)
		end
	end
end

function button:draw()
	if self.t == "main" or self.t == "slider" then
		love.graphics.setColor(85, 48, 0)
		love.graphics.rectangle("fill", self.x*scale, (self.y+self.yoffset)*scale, self.width*scale, (self.height+1)*scale)
		love.graphics.setColor(253, 254, 253)
		love.graphics.rectangle("fill", (self.x+1)*scale, (self.y+1+self.yoffset)*scale, (self.width-2)*scale, (self.height-2)*scale)
		love.graphics.setColor(232, 97, 0)
		love.graphics.rectangle("fill", (self.x+2)*scale, (self.y+2+self.yoffset)*scale, (self.width-4)*scale, (self.height-4)*scale)
		love.graphics.setColor(191, 78, 1)
		printtext(self.text, (self.x+(self.width/2)-(self.text:getTextWidth()/2))*scale, (self.y+(self.height/2)+self.yoffset-1.5)*scale)
		love.graphics.setColor(253, 254, 253)
		printtext(self.text, (self.x+(self.width/2)-(self.text:getTextWidth()/2))*scale, (self.y+(self.height/2)+self.yoffset-2.5)*scale)
	end
end

function button:checkmouseon()
	local x, y = love.mouse.getPosition(); return x>self.x*scale and y>self.y*scale and x<(self.x+self.width)*scale and y<(self.y+self.height)*scale
end

function button:mousepressed(x, y, button)
	if self.static then
		return
	end
	if button == "l" then
		if self.mouseon then
			self.yoffset = 1
		end
	end
end

function button:mousereleased(x, y, button)
	if self.static then
		return
	end
	if button == "l" then
		if self.mouseon and not self.static and self.t == "main" then
			if self.arg then
				self.func(unpack(self.arg))
			else
				self.func()
			end
		end
		self.yoffset = 0
	end
end