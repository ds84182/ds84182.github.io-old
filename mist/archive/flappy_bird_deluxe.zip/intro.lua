intro = {}

function intro.load()
	love.graphics.setBackgroundColor(0,0,0)

	introfade = 255
	introimgy = 256
	intropart = 1
	introtimer = 0
end

function intro.update(dt)
	if intropart == 1 then
		if introimgy > 60 then
			introimgy = introimgy - 200*dt;introimgy = math.max(60, introimgy)
		else
			intropart = 2
		end
	elseif intropart == 2 then
		introtimer = introtimer + dt
		if introtimer >= 1 then
			intropart = 3
			introtimer = 0
		end
	elseif intropart == 3 then
		introfade = introfade - 150*dt;introfade = math.max(0,introfade)
		if introfade <= 0 then
			setgamestate("menu")
			return
		end
	end
end

function intro.draw()
	love.graphics.setColor(255, 255, 255, introfade)
	love.graphics.draw(alesanimg, 10*scale, introimgy*scale, 0, scale, scale)
end

function intro.keypressed()
	setgamestate("menu")
end

function intro.mousepressed(x, y, button)
	if button == "l" or button == "r" then
		setgamestate("menu")
	end
end