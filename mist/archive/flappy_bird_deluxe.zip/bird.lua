bird = class:new()

function bird:init(x, t)
	self.x = x+1
	self.y = 100+1
	self.width = 15
	self.height = 12
	self.speedx = 0
	self.speedy = 0
	self.gravity = 500
	self.t = t
	
	self.flap = false
	
	self.rotation = math.rad(0)
	
	self.frame = 2
	self.animtimer = 0
	
	--*sigh*
	self.diesoundtimer = 0
	self.diesound = false
end

function bird:update(dt)
	if not self.dead then
		local collided = self:checkCollision()
		
		if collided then
			if not self.dead then
				self.dead = true
				playsound(hitsound)
				self.diesound = true
			end
		end
	end
	
	if self.diesound then
		self.diesoundtimer = self.diesoundtimer + dt
		if self.diesoundtimer >= .3 then
			playsound(diesound)
			self.diesound = false
		end
	end
	
	if self.dead and players > 1 and doscroll then
		self.x = self.x - 60*dt
	end
	
	if not self.static and self.flap then
		if self.speedy < 300 then
			self.speedy = self.speedy + self.gravity*dt
		end
		self.y = self.y + self.speedy*dt
		if self.y >= 186 then
			self.y = 186
			if self.dead then
				self.static = true
			else
				self.dead = true
				self.static = true
				playsound(hitsound)
			end
		end
		
		if self.dead then else
			self.animtimer = self.animtimer + dt
			while self.animtimer > 0.1 do
				self.frame = self.frame + 1
				if self.frame > 4 then
					self.frame = 1
				end
				self.animtimer = self.animtimer - 0.1
			end
		end
		self.rotation = math.rad(math.min(90, math.max(-20, self.speedy-140)))
	elseif not self.flap then
		self.y = floatoffsety + 100
	end
end

function bird:draw()
	love.graphics.setColor(255, 255, 255)
	love.graphics.draw(birdimg, birdquad[self.frame][self.t], (self.x+5)*scale, (self.y+5)*scale, self.rotation, scale, scale, 6, 6)
	if players > 1 and champ[difficultynum] == self.t then
		love.graphics.draw(crownimg, (self.x+5)*scale, (self.y+5)*scale, self.rotation, scale, scale, 0, 10)
	end
end

function bird:checkCollision()
	for j, w in pairs(objects.pipe) do
		if self.x < w.x+w.width and w.x < self.x+self.width and self.y < w.y+w.height and w.y < self.y+self.height then
			return true
		end
	end
	return false
end

function bird:keypressed(key)
	if self.dead or (players > 1 and (self.t ~= 1 and self.t ~= 3 and self.t ~= 4)) then
		return
	end
	if players > 1 then
		if key == " " and self.t ~= 3 then
			return
		end
		if key ~= " " and self.t ==  3 then
			return
		end
		if key == "up" and self.t ~= 4 then
			return
		end
		if key ~= "up" and self.t ==  4 then
			return
		end
	end
	if not self.flap then
		self.flap = true
	end
	if self.y > 0 then 
		self.speedy = -160
		playsound(flapsound)
	end
end

function bird:mousepressed(x, y, button)
	if button == "l" and (objects.button.pause and not objects.button.pause.mouseon) then
		if self.dead or (players > 1 and self.t ~= 2) then
			return
		end
		if not self.flap then
			self.flap = true
		end
		if self.y > 0 then
			self.speedy = -160
			playsound(flapsound)
		end
	end
end