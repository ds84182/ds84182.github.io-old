function love.conf(t)
	if love._version == "0.9.1" then
		t.version = "0.9.1"
	else
		t.version = "0.9.0"
	end
end